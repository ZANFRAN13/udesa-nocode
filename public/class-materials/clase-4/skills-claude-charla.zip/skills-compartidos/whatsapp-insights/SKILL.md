---
name: whatsapp-insights
description: "/whatsapp-insights — Leer las conversaciones de clientes de un período (WhatsApp, chat de la web, mails) desde un Google Sheet o un archivo, y sacar los 3 insights más fuertes, cada uno con evidencia, una cita textual del cliente y una acción concreta para este mes. Usar cuando el usuario pide los insights de WhatsApp, 'qué nos están diciendo los clientes', o /whatsapp-insights."
user-invocable: true
---

# /whatsapp-insights: qué nos dicen los clientes, en 3 insights accionables

## Uso
- `/whatsapp-insights`: el mes actual
- `/whatsapp-insights 2026-10` o `/whatsapp-insights octubre`: un mes puntual (si solo se da el mes, se toma el año actual)

## Dónde están las conversaciones
Configurá una de estas dos fuentes en el `CLAUDE.md` del proyecto:
- **Google Sheet** (con un MCP de Google Sheets): una fila por conversación, con las columnas `id, cliente, perfil, conversación, producto recomendado, razón, cantidad de mensajes, primer mensaje, fecha (YYYY-MM-DD)`.
- **Archivo** (JSON o CSV) con los mismos campos.

Si exportás chats reales, sacá antes los teléfonos y los apellidos: con un nombre de pila y un perfil alcanza.

## Pasos

### 1) Filtrar el período
Quedate con las conversaciones cuya `fecha` cae en el período. Decí cuántas quedaron afuera por no tener fecha. Si el período no tiene conversaciones, frená y decí qué meses sí tienen datos. No inventes.

### 2) Leer y contar
Leé **cada** conversación completa y contá:
- el producto que se recomienda primero;
- las ventas cerradas (el cliente confirma la compra en el chat);
- el segundo producto sugerido y si se lo llevó;
- de dónde llegó (un reel, una recomendación, un profesional, un revendedor);
- las dudas que se repiten;
- las frases del equipo que suenan a promesa de salud o a claim no permitido.

### 3) Elegir los 3 insights más fuertes
Ordenalos por impacto en el negocio. Cada uno tiene que:
- estar respaldado por al menos 2 conversaciones o por un número ("8 de 15");
- traer **una cita textual del cliente** (no del vendedor) con su id;
- terminar en **una acción concreta** que el equipo pueda hacer este mes.

Preferí oportunidades de venta (el producto de entrada, un cross-sell sin seguimiento, los que recomiendan, los mayoristas) por sobre observaciones genéricas. Un riesgo fuerte (claims, seguridad) puede ser uno de los tres.

### 4) Entregar
En el chat, o como una slide o un doc si hay un MCP de Google Slides o Docs:

```
<Período> · N conversaciones · M cerraron venta · <producto más pedido>

1. <Título del insight, ≤60 caracteres>
   "<cita del cliente>" (<id>)
   → <acción concreta, ≤130 caracteres>
2. …
3. …
Fuente: <sheet o archivo> · corrido el <fecha>
```

### 5) Siguiente paso posible
Los insights son el input de `/ad-script` (el hook y la promesa salen de las frases de los clientes) y de `/refine-visual` (por ejemplo, un quiz para "no sé cuál elegir").
