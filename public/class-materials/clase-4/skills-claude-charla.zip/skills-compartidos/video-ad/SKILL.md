---
name: video-ad
description: "/video-ad — Renderizar un ad de video vertical (9:16, Reels y Stories) con Remotion a partir de un guion ya aprobado (/ad-script). Arma la composición beat por beat con las fotos o el footage del producto, la marca y la placa final con precio; renderiza cortes de 15 s y 12 s más un thumbnail; y revisa un frame cada 0,5 s antes de darlo por terminado. Usar cuando hay un guion aprobado y hay que convertirlo en MP4."
user-invocable: true
---

# /video-ad: del beat sheet al MP4

Remotion arma videos con React: cada frame es un componente y el tiempo es una variable. Sirve para ads porque el guion se pasa casi literal a código, y cambiar un texto o un precio es re-renderizar, no reeditar.

## Requisitos
- Node 18+ y un proyecto Remotion (`npx create-video@latest`, plantilla en blanco).
- El beat sheet aprobado (`SCRIPTS.md` de `/ad-script`).
- Los assets: fotos reales del producto, imágenes generadas que pasaron el chequeo de etiqueta, y stock footage con licencia.
- Las fuentes de la marca (`.otf`, `.ttf`) y una música con licencia que permita usarla en ads.

## 1) Assets
Copiá todo a `public/<marca>/<slug>/` y escribí un `LICENSES.md` con el origen y la licencia de cada archivo. Si hay que sacarle el fondo a un packshot blanco, hacé un PNG recortado. Ojo con el reflejo del piso: suele quedar como un disco blanco.

## 2) Composición
Una carpeta `src/<Marca>Ads/` con tres archivos:
- `datos.ts`: los beats como datos (`t`, `dur`, imagen, encuadre, zoom, texto) y el precio. Así un cambio de guion es un cambio de datos.
- `Anuncio.tsx`: los componentes (`Plano`, `Texto`, `Chip`, `Cierre`) y la composición.
- `index.tsx`: registra un `<Composition>` por corte (15 s = 450 frames y 12 s = 360, a 30 fps, 1080×1920). Registralo en `src/Root.tsx`.

Los ids de composición aceptan solo `a-zA-Z0-9-`: un guion bajo hace fallar el render.

**Fuentes**: cargalas con `FontFace` dentro de `delayRender`/`continueRender`, para que el render espere a que estén.

**Estilo de base** (adaptalo a tu marca):
- Fotos con push-in lento (`scale` de 1.05 a 1.15 durante el beat) y `object-position` elegido por beat, para que el recorte vertical no corte la mano ni el frasco.
- Placas de texto con la fuente de la marca, ≤8 palabras, con entrada suave (`spring` con `damping: 200`).
- Un chip de marca arriba desde el frame 0.
- La placa final dura ≈1,8 s: el producto cae con un `spring`, aparecen el nombre, el precio contando y el botón.
- Música suave, con fade in y fade out.

**Zona segura 9:16**: todo lo importante entre y = 270 y y = 1248 px. Arriba y abajo los tapa la interfaz de Reels.

## 3) Render
```bash
npx remotion render <Id-15> out/<slug>/ad-15.mp4 --codec h264
npx remotion render <Id-12> out/<slug>/ad-12.mp4 --codec h264
npx remotion still  <Id-15> out/<slug>/ad-15-thumb.jpg --frame=60
```

## 4) Revisar antes de darlo por terminado
Sacá un frame cada 0,5 s y miralos juntos en una hoja de contactos:
```bash
ffmpeg -i ad-15.mp4 -vf "fps=2,scale=270:-1" f%02d.png
```
Chequeá:
- [ ] el texto queda dentro de la zona segura y no tapa la etiqueta;
- [ ] no hay dos productos superpuestos ni bandas vacías;
- [ ] la placa final no muestra estados intermedios raros (un "$0" antes del precio, por ejemplo);
- [ ] **la etiqueta del producto, revisada en un recorte a resolución completa**: en miniatura los errores de las imágenes generadas no se ven.

Corregí, volvé a renderizar y revisá de nuevo.

## 5) Para subir
Meta acepta MP4 H.264. Algunas herramientas de subida limitan el tamaño; para bajarlo sin que se note:
```bash
ffmpeg -i ad-15.mp4 -c:v libx264 -crf 21 -preset slow -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart ad-15-meta.mp4
```
El paso siguiente es `/meta-ads-pausado`.
