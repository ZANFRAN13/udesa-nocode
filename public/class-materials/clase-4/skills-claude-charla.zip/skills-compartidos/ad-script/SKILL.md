---
name: ad-script
description: "/ad-script — Escribir guiones de video vertical (Reels y Stories de Instagram/Facebook) para una marca de producto físico. Arranca de lo que dicen los clientes, busca qué corre la competencia (Meta Ad Library), escribe tres conceptos distintos, los puntúa con una rúbrica fija (Google ABCD, diversificación de creativos de Meta, límites de claims del rubro y la política de salud de Meta), hace un persona test y entrega todo en una página HTML. El paso siguiente es /video-ad. Usar cuando el usuario pide un ad, un guion, hooks o un concepto para un producto, o antes de renderizar cualquier ad."
user-invocable: true
---

# /ad-script: brief → referencias → tres conceptos → puntaje → persona test → página → /video-ad

La regla de oro: **no se renderiza ni un frame antes de que el guion pase la rúbrica.** Este skill termina en un guion y una página; el video lo hace `/video-ad` y la subida a Meta es un paso aparte.

## 0) Leer primero
- La **ficha de marca** del proyecto: qué vende, a quién, paleta, tipografías, voz, claims permitidos (ver la tabla del paso 1).
- El **catálogo con precios de hoy**. Nunca pongas un precio de memoria: chequealo en la tienda.
- **Lo que dicen los clientes**: chats de WhatsApp, mails, reseñas. Es el input más valioso del guion.

## 1) El brief (completá todo, o preguntá)
| Campo | Ejemplo |
|---|---|
| Producto + URL de destino | Chequeá que la página cargue (200) antes de usarla |
| Precio + oferta | De la tienda, hoy: cuotas, descuento por transferencia |
| Comprador | Edad, zona, rutina, qué ya compra |
| Nivel de conciencia (Schwartz) | Frío = sabe que tiene el problema; retargeting = ya conoce el producto |
| La promesa | Una sola oración. Una sensación o un ritual, nunca una cura |
| Pruebas disponibles | Solo datos reales: quién lo formula, certificaciones, origen |
| Placement y duración | Reels + Stories, 15 s y 12 s, 1080×1920 |
| Idioma y voz | Por ejemplo, castellano rioplatense con *vos* |

## 2) Qué dicen los clientes (si hay conversaciones)
Leé todas las conversaciones completas y anotá:
- qué producto se recomienda primero y cuántas veces;
- **las frases textuales** con que los clientes describen el momento o el problema;
- las dudas que se repiten y las objeciones;
- el gesto o ritual concreto de uso, si aparece;
- **las frases del equipo de ventas que suenan a claim de salud**: esas nunca van a un ad.

Cada insight tiene que estar respaldado por al menos dos conversaciones, o por un número ("8 de 15").

## 3) Búsqueda de referencias (antes de escribir; 10–15 min)
- **Meta Ad Library** (`facebook.com/ads/library`): tu país y, como mercado más maduro, Estados Unidos. Buscá el producto, el ingrediente y el problema. Si tenés el MCP oficial de Meta Ads, `ads_library_search` lo hace sin navegador.
- Los competidores que se venden al lado tuyo (marketplaces, tiendas multimarca).
- TikTok Creative Center → Top Ads de tu categoría.

Para 5 a 8 referencias anotá la marca, el hook (los primeros 2 s), el formato, el claim, el CTA y cuánto tiempo lleva corriendo (lo que corre hace meses suele funcionar). Cerrá con **una línea**: qué va a hacer tu concepto que ninguno de ellos hace.

## 4) Tres conceptos DISTINTOS
Meta agrupa los ads que se parecen: un recorte o un cambio de texto cuentan como el **mismo** ad. Los tres conceptos tienen que diferir en al menos dos de estas cosas: el material (footage, fotos), el formato (manos y piel / ritual en un espacio / fundador o laboratorio / macro de producto), el tipo de hook y el momento de uso.

Cada concepto es un beat sheet:
```
t     qué se VE (plano)                         texto en pantalla (≤8 palabras)   fuente
0.0   …                                         …                                 pexels:<id> | foto:<archivo> | ui
```

## 5) Puntaje (todo tiene que pasar; se corrige y se vuelve a puntuar, no se discute)
**Atención**
- [ ] El producto (o el producto en uso) se ve antes de 1,5 s. Sin placa de título ni preámbulo.
- [ ] Hay movimiento en el primer frame y el primer corte llega antes de 2,5 s.
- [ ] El hook nombra un momento que el espectador vive ("antes de apagar la luz"), no un síntoma que tiene.

**Marca**
- [ ] La marca está en pantalla desde 0 s (un chip chico) y el producto vuelve a aparecer en la placa final.
- [ ] Usa los colores y las tipografías de la marca.
- [ ] **La etiqueta se lee bien cada vez que el producto está en cuadro, revisada a resolución completa.** Las imágenes generadas con IA suelen escribir mal la letra chica.

**Conexión**
- [ ] **Una sola idea.** Escribila en una oración; si necesita un "y", cortá.
- [ ] Hay personas: manos, hombros, un cuerpo en movimiento. No solo frascos sobre una mesa.
- [ ] El texto va a ≤10 palabras por segundo, ≤8 palabras por placa y ≤2 líneas, y se entiende sin sonido.
- [ ] Dice la conclusión de forma explícita.

**Dirección**
- [ ] Un solo CTA, que coincide con el botón y la landing; el precio está en la placa final.
- [ ] La placa final dura ≈1,8 s y tiene movimiento (el producto aterriza, aparece el precio).

**Cumplimiento**
- [ ] **Solo claims permitidos para tu rubro.** En cosmética, nada de "cura", "trata", "elimina", "antiinflamatorio": hablá de sensaciones y rituales ("una sensación de alivio").
- [ ] **Atributos personales de Meta:** ninguna línea que afirme o insinúe la salud, el cuerpo o la condición del espectador ("¿Te duele la espalda?", "¿Dormís mal?"). Hablá del momento y del producto.
- [ ] Nada de antes/después ni de autoimagen negativa.
- [ ] Cada precio, oferta y número sale de la tienda hoy.

**Honestidad y assets**
- [ ] El producto es una foto real, o una imagen generada que pasó el chequeo de etiqueta. **Nunca un producto inventado.**
- [ ] El stock footage tiene licencia por escrito (Pexels, por ejemplo) y está registrado en un `LICENSES.md`. Una sola sesión de fotos por ad, para que la persona no cambie a mitad del ad.
- [ ] El material coincide con el momento que nombra el hook.
- [ ] Si hay personas generadas con IA, no se presentan como clientes reales.

Puntuá en una tabla de concepto × chequeo, con ✅/❌ y una línea de arreglo por cada ❌.

## 6) Persona test (obligatorio)
Simulá tres espectadores parecidos al comprador. Para cada uno: en qué segundo scrollea, qué cree que es el producto a los 3 s, qué la haría tocar el botón y si algo le suena a promesa médica. Corregí todo lo que les pase a dos de los tres.

## 7) La página
Una página HTML con estas secciones:
1. **Brief**: la tabla completa.
2. **Lo que dijeron los clientes**: los insights con sus citas.
3. **Referencias**: una tarjeta por referencia, más la línea de "lo que hacemos que ellos no".
4. **Conceptos**: cada uno como storyboard (tiempo, plano, texto en pantalla), con su tabla de puntaje.
5. **Persona test**: los tres espectadores y qué se corrigió.
6. **Recomendación**: qué concepto va primero y por qué, y el pase a `/video-ad`.

Guardá también los beat sheets en `SCRIPTS.md` y el puntaje y el persona test en `FINDINGS.md`, al lado del video.

## 8) Pase a /video-ad
Solo cuando el concepto elegido pasa la rúbrica. Pasale el beat sheet, los assets y la ficha de marca.

## 9) Después de renderizar (fuera de este skill)
Subir a Meta siempre en **PAUSED** (ver `/meta-ads-pausado`). Después del lanzamiento: el día 3 apagá el concepto cuyo hook rate (vistas de 3 s ÷ impresiones) esté por debajo del 25%; el día 14 compará costo por compra y tasa de agregado al carrito.
