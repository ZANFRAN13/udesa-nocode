#!/usr/bin/env python3
"""Arma la página de decisiones de /refine-visual.

Uso:  python3 build.py <data.json> <salida.html> [assets.json]

1. Reemplaza cada {{img:clave}} del JSON por la imagen incrustada (data URI).
   Las claves salen de assets.json: {"clave": "ruta/a/la/foto.jpg", ...}.
   Las rutas son relativas a la carpeta de assets.json. Usá fotos chicas
   (≈360 px de ancho) para que la página pese poco.
2. Valida y renderiza con render.py + template.html (están en esta misma carpeta).
3. Pone como <title> el `title` del JSON.

La página queda autocontenida: se abre local o se publica donde quieras.
"""
import base64
import json
import mimetypes
import pathlib
import re
import subprocess
import sys
import tempfile

HERE = pathlib.Path(__file__).resolve().parent


def data_uri(key, assets, base):
    if key not in assets:
        sys.exit(f"Imagen desconocida: {{{{img:{key}}}}}. Claves: {', '.join(assets)}")
    src = (base / assets[key]).resolve()
    if not src.exists():
        sys.exit(f"No existe {src}")
    mime = mimetypes.guess_type(src.name)[0] or "image/jpeg"
    return f"data:{mime};base64," + base64.b64encode(src.read_bytes()).decode()


def main():
    if len(sys.argv) not in (3, 4):
        sys.exit(__doc__)
    src, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
    assets_path = pathlib.Path(sys.argv[3]) if len(sys.argv) == 4 else HERE / "assets.json"
    assets = json.loads(assets_path.read_text()) if assets_path.exists() else {}
    raw = src.read_text()
    cache = {}
    raw = re.sub(r"\{\{img:([a-z0-9-]+)\}\}",
                 lambda m: cache.setdefault(m.group(1), data_uri(m.group(1), assets, assets_path.parent)), raw)
    title = json.loads(raw)["title"]
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as tmp:
        tmp.write(raw)
    r = subprocess.run([sys.executable, str(HERE / "render.py"), tmp.name, str(out)], capture_output=True, text=True)
    if r.returncode:
        sys.exit(r.stderr)
    html = out.read_text()
    html = html.replace("<title>Refine decisions</title>", f"<title>{title}</title>", 1)
    html = html.replace('<html lang="en">', '<html lang="es">', 1)
    out.write_text(html)
    print(r.stdout.strip(), f"· {len(cache)} imágenes incrustadas · {len(html) // 1024} KB")


if __name__ == "__main__":
    main()
