---
name: refine-visual
description: "/refine-visual — Definir una mejora para una tienda online (un modal, una sección, un quiz, un flujo de compra) con una página de decisiones visual antes de construirla. Junta el contexto de la marca, los productos reales y lo que preguntan los clientes; busca benchmarks de ecommerce; parte la mejora en decisiones y muestra cada una con 2 a 4 alternativas en mockup para elegir. Usar cuando el usuario pide /refine-visual o quiere decidir visualmente una feature de su tienda antes de codearla."
user-invocable: true
---

# /refine-visual: decidir una mejora de la tienda eligiendo con imágenes

El resultado es una página HTML donde cada decisión de producto es una tarjeta con 2 a 4 alternativas lado a lado. Cada alternativa tiene un mockup, pros, contras y esfuerzo, y una de ellas está marcada como recomendada. El usuario elige, agrega notas, aprieta **Copy answers** y pega el bloque en el chat. Recién ahí se construye.

## Antes de usarlo: la ficha de tu marca
Completá esta tabla una vez (por ejemplo en el `CLAUDE.md` de tu proyecto). El skill la lee en cada corrida.

| Campo | Qué poner |
|---|---|
| Marca y rubro | Nombre, qué vende, a quién |
| Plataforma | Tienda Nube, Shopify, WooCommerce… y dónde está el código del tema |
| Paleta | 4 a 7 colores en hex, y cuál es el de acento |
| Tipografía | Fuente de títulos y fuente de texto |
| Voz | 2 o 3 adjetivos, y cómo NO tiene que sonar |
| Catálogo | Dónde están los productos, precios y URLs (un CSV, un export, la propia tienda) |
| Fotos | Las fotos de producto, en un `assets.json` (ver el paso 5) |
| Lo que preguntan los clientes | Chats de WhatsApp, mails, reseñas, tickets |
| Límites de claims | Lo que tu rubro no puede decir. Por ejemplo, la cosmética en Argentina (ANMAT) no puede decir "cura", "trata" ni "elimina el dolor" |
| Tienda de prueba | La URL donde se prueba antes de publicar |

## Uso
`/refine-visual <la mejora>`. Por ejemplo: `/refine-visual un quiz que recomiende qué producto te conviene`.

## 1) Entender
Escribí en una o dos líneas qué mejora es, en qué páginas vive y qué tiene que lograr: más conversión, ticket más alto, menos consultas. Si el objetivo no está claro, preguntalo antes de seguir.

## 2) Contexto: usar lo que ya existe
Leelo, no lo supongas: la ficha de marca, el catálogo real (con precios de hoy), el código del tema y, sobre todo, **lo que preguntan los clientes**. Contá cuántas veces aparece cada duda y anotá citas textuales: son la mejor evidencia para recomendar una opción. Chequeá que existan las URLs de producto que vas a usar.

## 3) Benchmarks
Hacé una o dos búsquedas web sobre el patrón de la mejora: tasas de conversión, cantidad de pasos, disparadores, ejemplos de marcas parecidas. Citá los números con su fuente, y aclará cuando el dato lo publica un proveedor que vende esa herramienta. Si los datos se contradicen, decilo.

## 4) Partir la mejora en decisiones (8 a 15)
Revisá estos ejes y quedate solo con los que sean una elección real:
1. **Disparador y ubicación**: botón, popup con demora, banner, exit-intent; en qué páginas.
2. **Estructura**: cuántos pasos y qué pregunta cada uno.
3. **Contenido de cada paso**: cómo se muestran las opciones (ícono, foto, texto) y cómo se nombran, respetando los límites de claims.
4. **Lógica**: cómo se pasa de las respuestas al producto. Mostrala como tabla.
5. **Resultado**: un producto, producto + combo o un ranking; con o sin el "por qué".
6. **Conversión**: agregar al carrito directo o ir a la ficha; captura de email; cupón.
7. **Look & feel**: estética y comportamiento en mobile.
8. **Medición**: qué eventos medir y cómo atribuir las ventas.

Lo que podés decidir vos va en `defaults` y no en tarjetas, siempre visible para que se pueda cambiar.

## 5) Mockups
Cada opción que se vea distinta lleva un `visual`:
- `html`: un mockup chico (≈300×220) con estilos inline y los colores literales de la marca.
- `svg`: íconos, diagramas de flujo, barras de progreso.
- Fotos de producto: poné `{{img:clave}}` en el `src` de un `<img>`. `build.py` la reemplaza por la imagen incrustada según tu `assets.json`, que tiene esta forma: `{"producto-a": "fotos/producto-a.jpg"}`.

Las opciones tienen que ser realmente distintas, y la recomendada tiene que tener un `why` basado en la evidencia (marca, clientes, benchmark).

## 6) Armar la página
Escribí el JSON de datos (el esquema está más abajo) y corré:

```bash
python3 <carpeta-del-skill>/build.py datos.json refine-visual-<slug>.html [assets.json]
```

Abrila en el navegador. Explicá en una línea cómo se usa: elegir, sumar notas, **Copy answers** y pegar el bloque acá ("Accept recommended" completa lo que falte con lo recomendado). Después esperá las respuestas: no construyas nada antes.

## 7) Con las respuestas: el plan
Las notas y los "other" pesan más que las opciones elegidas. El plan tiene tres partes:
- **Implementación**: un componente o snippet del tema, con los textos y las URLs editables desde el admin de la tienda.
- **Deploy**: primero a la tienda de prueba, con backup del tema antes.
- **Verificación**: recorrer el flujo en desktop y mobile y confirmar que el carrito agrega el producto correcto.

## Esquema de datos

```json
{
  "id": "quiz-producto-2026-11",
  "title": "Quiz: qué producto te conviene",
  "subtitle": "Decisiones antes de construirlo",
  "summary": "Qué es esta página y cómo usarla.",
  "context": ["Hallazgo con evidencia: 8 de 15 chats preguntan cuál elegir"],
  "defaults": ["Decidido sin preguntar: …"],
  "sections": [
    {
      "title": "Estructura",
      "decisions": [
        {
          "id": "E1",
          "question": "¿Cuántos pasos tiene el quiz?",
          "context": "Evidencia…",
          "impact": "high",
          "options": [
            { "id": "A", "label": "1 pregunta", "summary": "…", "pros": ["…"], "cons": ["…"], "effort": "S",
              "recommended": true, "why": "…",
              "visual": { "kind": "html", "content": "<div style='…'>…</div>" } },
            { "id": "B", "label": "3 preguntas", "summary": "…", "effort": "M" }
          ]
        }
      ]
    }
  ]
}
```

- `impact`: `high`, `medium` o `low`. `multi: true` si se puede elegir más de una opción.
- `visual.kind`: `html`, `svg`, `code` o `image` (`image` usa `src` en vez de `content`).
- Los textos aceptan `**negrita**`, `` `código` `` y `[link](url)`.
- `render.py` valida (ids únicos, 2 a 5 opciones, una sola recomendada) y falla si algo está mal. Corregí el JSON y volvé a correrlo; nunca edites el HTML a mano.

## Archivos
- `build.py`: incrusta las fotos y llama a `render.py`.
- `render.py` + `template.html`: la página (tarjetas, notas, progreso, Copy answers, tema claro y oscuro, versión mobile).
