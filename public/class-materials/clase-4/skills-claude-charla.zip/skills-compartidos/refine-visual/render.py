#!/usr/bin/env python3
"""Render a /refinehtml decision page: validate the data JSON, inline it into template.html.

Usage: python3 render.py <data.json> <out.html>
Exits non-zero with every problem listed, so the data can be fixed and re-rendered.
"""
import json
import pathlib
import sys

KINDS = {"html", "svg", "mermaid", "code", "image"}
IMPACTS = {"high", "medium", "low"}


def validate(data):
    errs = []
    if not data.get("id"):
        errs.append("top-level 'id' is required (stable slug: answers are remembered per id)")
    if not data.get("title"):
        errs.append("top-level 'title' is required")
    secs = data.get("sections") or []
    if not secs:
        errs.append("'sections' must hold at least one section with decisions")
    seen = set()
    for si, sec in enumerate(secs):
        where = f"section {si} ({sec.get('title', '?')})"
        if not sec.get("title"):
            errs.append(f"{where}: 'title' is required")
        for d in sec.get("decisions") or []:
            did = d.get("id")
            w = f"{where} / decision {did or '?'}"
            if not did:
                errs.append(f"{w}: 'id' is required")
            elif did in seen:
                errs.append(f"{w}: duplicate decision id")
            seen.add(did)
            if not d.get("question"):
                errs.append(f"{w}: 'question' is required")
            if d.get("impact") and d["impact"] not in IMPACTS:
                errs.append(f"{w}: impact must be one of {sorted(IMPACTS)}")
            opts = d.get("options") or []
            if not 2 <= len(opts) <= 5:
                errs.append(f"{w}: needs 2-5 options (has {len(opts)})")
            oids = [o.get("id") for o in opts]
            if len(set(oids)) != len(oids) or not all(oids):
                errs.append(f"{w}: option ids must be present and unique")
            recs = [o for o in opts if o.get("recommended")]
            if not d.get("multi") and len(recs) > 1:
                errs.append(f"{w}: single-choice decision has {len(recs)} recommended options")
            for o in opts:
                if not o.get("label"):
                    errs.append(f"{w} / option {o.get('id')}: 'label' is required")
                v = o.get("visual")
                if v:
                    if v.get("kind") not in KINDS:
                        errs.append(f"{w} / option {o.get('id')}: visual.kind must be one of {sorted(KINDS)}")
                    elif v["kind"] == "image" and not v.get("src"):
                        errs.append(f"{w} / option {o.get('id')}: image visual needs 'src'")
                    elif v["kind"] != "image" and not v.get("content"):
                        errs.append(f"{w} / option {o.get('id')}: visual needs 'content'")
    return errs


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    src, out = map(pathlib.Path, sys.argv[1:])
    data = json.loads(src.read_text())
    errs = validate(data)
    if errs:
        print("Data problems:\n- " + "\n- ".join(errs), file=sys.stderr)
        sys.exit(1)
    template = (pathlib.Path(__file__).parent / "template.html").read_text()
    # Inline safely inside <script type="application/json">.
    blob = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")
    out.write_text(template.replace("/*__REFINE_DATA__*/", blob))
    n = sum(len(s.get("decisions") or []) for s in data["sections"])
    print(f"Rendered {n} decisions in {len(data['sections'])} sections → {out}")


if __name__ == "__main__":
    main()
