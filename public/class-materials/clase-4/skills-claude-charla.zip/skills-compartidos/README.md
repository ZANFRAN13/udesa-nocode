# Skills de la charla: de lo que dicen los clientes a un ad en Meta

Cinco skills de Claude Code que se encadenan. Son versiones genéricas de las que usamos en vivo con una marca de cosmética: los datos de la marca los ponés vos.

| Skill | Qué hace | Entra | Sale |
|---|---|---|---|
| `whatsapp-insights` | Lee las conversaciones del mes y saca 3 insights con evidencia y una acción cada uno | Un Sheet o un archivo con los chats | 3 insights accionables |
| `refine-visual` | Define una mejora de la tienda con una página de decisiones visual | La idea + la marca + lo que preguntan los clientes | Una página HTML para elegir, y después un plan |
| `ad-script` | Escribe 3 conceptos de ad vertical, los puntúa y les hace un persona test | Producto + clientes + competencia | Guion aprobado + página de resumen |
| `video-ad` | Renderiza el guion con Remotion y lo revisa frame por frame | El guion + las fotos | MP4 de 15 s y 12 s + thumbnail |
| `meta-ads-pausado` | Sube el video y arma campaña, conjunto y anuncio en Meta, todo pausado | El MP4 + el copy | El anuncio en el Ads Manager, sin activar |

## Cómo instalarlas
1. Copiá cada carpeta a `~/.claude/skills/` (para todos tus proyectos) o a `.claude/skills/` dentro de tu proyecto. Ejemplo: `~/.claude/skills/ad-script/SKILL.md`.
2. En el `CLAUDE.md` de tu proyecto escribí la **ficha de marca**: qué vendés, a quién, colores, tipografías, voz, dónde están el catálogo y las fotos, y qué no podés decir (los claims que tu rubro no permite).
3. En Claude Code escribí `/ad-script <producto>` (o el skill que quieras). Claude lee el `SKILL.md` y sigue los pasos.

## Qué necesita cada una
- `whatsapp-insights`: un MCP de Google Sheets, o los chats en un JSON/CSV local. Si los chats son reales, anonimizalos antes (sin teléfonos ni apellidos).
- `refine-visual`: Python 3. Trae `build.py`, `render.py` y `template.html`.
- `ad-script`: búsqueda web; opcionalmente, el MCP oficial de Meta Ads, para buscar en la Ad Library sin navegador.
- `video-ad`: Node 18+, un proyecto Remotion (`npx create-video@latest`) y ffmpeg.
- `meta-ads-pausado`: el MCP oficial de Meta Ads, una cuenta publicitaria y una Page de Facebook.

## Lo que aprendimos haciéndolo
- **Los clientes escriben los mejores hooks.** "No quiero tomar pastillas" terminó siendo la placa central del ad.
- **El equipo de ventas dice cosas que un ad no puede decir** ("relaja el sistema nervioso", "actúa en 15 minutos"). La rúbrica las frena.
- **Revisá la etiqueta del producto a resolución completa.** Las imágenes generadas con IA escriben mal la letra chica. En miniatura no se ve; en la vista previa de Meta, sí.
- **Todo en Meta va pausado.** Activar es una decisión humana.
