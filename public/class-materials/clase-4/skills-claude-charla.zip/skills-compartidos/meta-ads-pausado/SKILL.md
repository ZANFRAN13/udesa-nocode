---
name: meta-ads-pausado
description: "/meta-ads-pausado — Subir un ad de video ya renderizado a Meta Ads (Facebook/Instagram) y armar campaña, conjunto, creative y anuncio, todo en PAUSED, con el MCP oficial de Meta Ads. Nunca activa nada. Usar después de /video-ad, cuando el usuario quiere ver el ad en el Ads Manager listo para revisar."
user-invocable: true
---

# /meta-ads-pausado: del MP4 al Ads Manager, sin gastar un peso

**Regla fija: todo se crea en PAUSED y nunca se activa.** Activar es decisión de una persona, en el Ads Manager.

## Requisitos
- El **MCP oficial de Meta Ads** conectado, con acceso a una cuenta publicitaria activa con medio de pago.
- Una **Page de Facebook** que la cuenta pueda usar (y una cuenta de Instagram vinculada si querés placements de Instagram).
- El MP4 (`/video-ad`), su thumbnail, el primary text, el headline y la URL de destino (`/ad-script`).

## Pasos

### 1) Cuenta y Page
`ads_get_ad_accounts` para ver las cuentas y su moneda (el presupuesto va en la unidad más chica: centavos). Confirmá con el usuario qué cuenta y qué Page usar. No uses la Page de otra marca.

### 2) Subir el video y el thumbnail
`ads_creative_upload_media`:
- **Archivo local**: `upload_source: LOCAL_FILE` abre un selector donde el usuario elige el archivo y aprieta Continue. Es la vía más simple.
- **Por URL**: `upload_source: URL` con una URL pública directa al MP4 (que devuelva los bytes, no una página de Drive o Dropbox). Si armás una URL temporal, borrala apenas Meta termine de recibir el archivo.

Esperá a que el video esté `ready` (`ads_get_ad_videos`) antes de usarlo en un creative.

### 3) Campaña → conjunto → creative → anuncio
- `ads_create_campaign`: objetivo `OUTCOME_TRAFFIC` (o `OUTCOME_SALES` si tenés pixel con eventos de compra). Nombrala para que se entienda que no se activa, por ejemplo "… (demo, NO ACTIVAR)".
- `ads_create_ad_set`: país, y la edad y el género como **sugerencia** para Advantage+ (no como límite). **El presupuesto lo dice el usuario; nunca lo inventes.** Mientras esté pausado no se gasta nada.
- `ads_create_creative`: video + thumbnail + primary text + headline + CTA (`SHOP_NOW`) + URL de destino. Antes de crearlo, preguntá si el creative usa contenido generado con IA (`self_ai_disclosure`): no se puede cambiar después.
- `ads_create_ad`: el anuncio, con el creative.

### 4) Verificar
- `ads_get_ad_entities` con el id del anuncio: confirmá que dice `PAUSED`.
- `ads_get_ad_preview` en `INSTAGRAM_REELS` o `FACEBOOK_REELS_MOBILE`, y pasá el link de la vista previa.
- **Mirá la vista previa a tamaño completo**: es la última oportunidad de ver un error en la etiqueta o en el texto antes de que alguien lo active.

### 5) Entregar
Los ids (campaña, conjunto, creative, anuncio), los links al Ads Manager y a la vista previa, el presupuesto que quedó cargado y la aclaración de que nada está activo.

## Trampas conocidas
- Si la cuenta trabaja en modo borrador, los objetos quedan como DRAFT hasta publicarlos. Si no, quedan en PAUSED. Las dos opciones están bien.
- Algunas herramientas de subida limitan el tamaño (10–15 MB). Re-encodeá con `crf 21` antes de subir (ver `/video-ad`).
- Entrar a la biblioteca de medios desde el navegador puede pedir un código de doble factor: eso lo tiene que hacer el usuario.
